#ifndef BOOL_EXPR_CLIENT_H
#define BOOL_EXPR_CLIENT_H

#include <string>
#include <vector>



// converts a buffer into a string
std::string buffer_To_string(std::vector<char> buffer, char endOfTransmission);


#endif // BOOL_EXPR_CLIENT_H